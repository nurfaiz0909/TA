<?php
require_once('connection.php');
$nama = $_POST['nama'];
$query = mysqli_query($CON,"SELECT nama,keterangan FROM `tbl_absensi` WHERE `nama`='$nama' AND keterangan='Absen Masuk'");
$row =  mysqli_fetch_row($query);

if (json_encode($row) == "null"){
    echo json_encode(array('message' => 'deny'));
  } else {
    echo json_encode(array('message' => 'allow'));
  }
