<?php
require_once('connection.php');
$nama = $_POST['nama'];
$tanggal = $_POST['tanggal'];
$status = $_POST['status'];

$query = mysqli_query($CON,"SELECT id,name as nama,bukti as foto_selfie,tanggal,lokasi,keterangan FROM `izin` WHERE `name`='$nama' AND tanggal='$tanggal'");
$row =  mysqli_fetch_row($query);
$query = mysqli_query($CON, "DELETE FROM `izin` WHERE id='$row[0]'");
if($status == "diterima"){
    $query = mysqli_query($CON, "INSERT INTO `tbl_absensi`(`nama`, `foto_selfie`, `tanggal`, `lokasi`, `keterangan`) VALUES ('$row[1]','$row[2]','$row[3]','$row[4]','Izin (Diterima)')");
} else {
    $query = mysqli_query($CON, "INSERT INTO `tbl_absensi`(`nama`, `foto_selfie`, `tanggal`, `lokasi`, `keterangan`) VALUES ('$row[1]','$row[2]','$row[3]','$row[4]','Izin (Ditolak)')");
}
echo json_encode(array('message' => 'Status Perizinan Telah Diupdate!'));
