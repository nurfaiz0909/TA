<?php
    $HOST = 'localhost';
    $USER = 'root';
    $PASS = '';
    $DB = 'ams';
    $CON = mysqli_connect($HOST,$USER,$PASS,$DB);
?>