<?php
require_once('connection.php');
$nama = $_POST['nama'];
$selfie = $_POST['selfie'];
$tanggal = $_POST['tanggal'];
$lokasi = $_POST['lokasi'];
$keterangan = $_POST['keterangan'];

if (!$nama || !$selfie || !$tanggal || !$lokasi || !$keterangan) {
    echo json_encode(array('message' => 'required field is empty.'));
} else {
    $query = mysqli_query($CON, "INSERT INTO `izin`(`name`, `bukti`, `tanggal`, `lokasi`, `keterangan`) VALUES ('$nama','$selfie','$tanggal','$lokasi','$keterangan')");
    if ($query) {
        echo json_encode(array('message' => 'Perizinan Anda terkirim, tunggu persetujuan dari admin!'));
    } else {
        echo json_encode(array('message' => 'failed'));
    }
}
