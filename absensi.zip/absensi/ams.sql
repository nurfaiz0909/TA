-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 04 Sep 2022 pada 02.51
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ams`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensipegawai`
--

CREATE TABLE `absensipegawai` (
  `uid` int(10) UNSIGNED NOT NULL,
  `id` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `selfie_masuk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selfie_pulang` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `jam_masuk` time DEFAULT NULL,
  `jam_pulang` time DEFAULT NULL,
  `jam_kerja` time DEFAULT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lokasi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `akunpegawai`
--

CREATE TABLE `akunpegawai` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_jabatan` int(10) UNSIGNED NOT NULL,
  `id_golongan` int(10) UNSIGNED DEFAULT NULL,
  `role` enum('Manager','Admin','Pegawai') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pegawai',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `akunpegawai`
--

INSERT INTO `akunpegawai` (`id`, `id_admin`, `name`, `id_jabatan`, `id_golongan`, `role`, `email`, `password`, `email_verified_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'user', 1, 1, 'Pegawai', 'user@gmail.com', 'd440aed189a13ff970dac7e7e8f987b2', NULL, NULL, '2022-07-22 08:45:09', '2022-07-22 08:45:09');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bonus`
--

CREATE TABLE `bonus` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(10) UNSIGNED NOT NULL,
  `jenis_bonus` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nominal` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cuti`
--

CREATE TABLE `cuti` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_pegawai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah_hari` int(11) NOT NULL,
  `tanggal_cuti` date NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_akhir` date NOT NULL,
  `jenis_cuti` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `bukti_cuti` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_cuti` enum('Diterima','Ditolak','Diproses') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Diproses',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `datagaji`
--

CREATE TABLE `datagaji` (
  `id` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `no_pegawai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_jabatan` int(10) UNSIGNED NOT NULL,
  `id_golongan` int(10) UNSIGNED DEFAULT NULL,
  `id_tunjangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_bonus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_potongan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_tunjangan` int(11) DEFAULT NULL,
  `total_bonus` int(11) DEFAULT NULL,
  `total_potongan` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `jam_kerja` time DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aktif',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `golongan`
--

CREATE TABLE `golongan` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(10) UNSIGNED NOT NULL,
  `golongan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pendidikan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nominal` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `golongan`
--

INSERT INTO `golongan` (`id`, `id_admin`, `golongan`, `pendidikan`, `nominal`, `created_at`, `updated_at`) VALUES
(1, 1, 'gol 1', 's2', 100, '2022-07-10 00:47:18', '2022-07-10 00:47:18'),
(2, 1, 'gol 2', 's1', 10, '2022-07-10 00:47:34', '2022-07-10 00:47:34');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hitung_gaji`
--

CREATE TABLE `hitung_gaji` (
  `id` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `no_gaji` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tunjangan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonus` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `potongan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nominal_tunjangan` int(11) DEFAULT NULL,
  `nominal_bonus` int(11) DEFAULT NULL,
  `nominal_potongan` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `izin`
--

CREATE TABLE `izin` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_pegawai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_izin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bukti` longblob NOT NULL,
  `status_izin` enum('Diproses','Diterima','Ditolak') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Diproses',
  `tanggal` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `lokasi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jabatan`
--

CREATE TABLE `jabatan` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(10) UNSIGNED NOT NULL,
  `jabatan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gaji` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `jabatan`
--

INSERT INTO `jabatan` (`id`, `id_admin`, `jabatan`, `gaji`, `created_at`, `updated_at`) VALUES
(1, 1, 'bos', 1000, '2022-07-10 00:46:14', '2022-07-10 00:46:14'),
(2, 1, 'karyawan', 100, '2022-07-10 00:46:28', '2022-07-10 00:46:28'),
(3, 1, 'admin', 1000, '2022-07-11 04:39:43', '2022-07-11 04:39:43'),
(4, 1, 'babu', 10, '2022-07-11 04:41:50', '2022-07-11 04:41:50');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jamabsen`
--

CREATE TABLE `jamabsen` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(10) UNSIGNED NOT NULL,
  `jam_masuk` time NOT NULL DEFAULT '00:00:00',
  `jam_pulang` time NOT NULL DEFAULT '00:00:00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan`
--

CREATE TABLE `laporan` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_pegawai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_laporan` date NOT NULL,
  `id_jabatan` int(10) UNSIGNED NOT NULL,
  `deskripsi` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `lampiran` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_laporan` enum('Diterima','Ditolak','Diproses') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Diproses',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `lembur`
--

CREATE TABLE `lembur` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_lembur` date NOT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_pegawai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jammulai` time NOT NULL,
  `jamselesai` time NOT NULL,
  `aktifitas` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `buktilembur` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_lembur` enum('Diterima','Ditolak','Diproses') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Diproses',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_05_07_013751_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_05_06_120505_create_perusahaan_table', 1),
(6, '2022_05_07_013316_create_jabatan_table', 1),
(7, '2022_05_7_160800_create_golongan_table', 1),
(8, '2022_06_17_164136_create_tunjangan_table', 1),
(9, '2022_06_18_030251_create_bonus_table', 1),
(10, '2022_06_20_035749_create_pegawais_table', 1),
(11, '2022_06_20_041650_create_jamabsen_table', 1),
(12, '2022_06_22_031302_create_potongan_table', 1),
(13, '2022_06_24_214644_create_akunpegawai_table', 1),
(14, '2022_06_29_071757_create_reqabsen_table', 1),
(15, '2022_06_29_071830_create_izin_table', 1),
(16, '2022_06_4_072941_create_absensipegawai_table', 1),
(17, '2022_07_01_131018_create_lembur_table', 1),
(18, '2022_07_01_140708_create_laporan_table', 1),
(19, '2022_07_04_043842_create_hitung_gaji_table', 1),
(20, '2022_07_04_105842_create_datagaji_table', 1),
(21, '2022_07_04_111428_create_cuti_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawais`
--

CREATE TABLE `pegawais` (
  `id` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `no_pegawai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pendidikan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_golongan` int(10) UNSIGNED DEFAULT NULL,
  `id_jabatan` int(10) UNSIGNED NOT NULL,
  `jam_kerja` time DEFAULT NULL,
  `no_ktp` bigint(20) DEFAULT NULL,
  `no_hp` bigint(20) DEFAULT NULL,
  `alamat` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('Aktif','Tidak Aktif') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Aktif',
  `gender` enum('Laki-Laki','Perempuan') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `logout_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pegawais`
--

INSERT INTO `pegawais` (`id`, `id_admin`, `no_pegawai`, `name`, `nama_lengkap`, `email`, `pendidikan`, `id_golongan`, `id_jabatan`, `jam_kerja`, `no_ktp`, `no_hp`, `alamat`, `status`, `gender`, `email_verified_at`, `created_at`, `updated_at`, `logout_at`) VALUES
(1, 1, 'PN521046973', 'user', NULL, 'user@gmail.com', NULL, 1, 1, NULL, NULL, NULL, NULL, 'Aktif', NULL, NULL, '2022-07-22 08:45:09', '2022-07-22 08:45:09', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'auth_token', '8dd38a07b11b215c9977a73a311e3bf5dc47320a8eed0b69b903edf74e885f9b', '[\"*\"]', NULL, '2022-07-10 00:45:40', '2022-07-10 00:45:40'),
(2, 'App\\Models\\User', 1, 'auth_token', 'f9d315cfcea60c573c00aa5d0f8d8d1fa95724bbf316f667a105729f00670074', '[\"*\"]', NULL, '2022-07-10 00:45:56', '2022-07-10 00:45:56'),
(3, 'App\\Models\\User', 1, 'auth_token', '9816c7a9c8bfde68e8d7b380d6ad5744b5b6712a2c6628870f8e494fa83781a5', '[\"*\"]', NULL, '2022-07-11 04:38:51', '2022-07-11 04:38:51'),
(4, 'App\\Models\\User', 1, 'auth_token', 'f3367177633c36b4184f20bcb300ea7e1a9b531ffcb3ea9cdb895150efd7ac8b', '[\"*\"]', NULL, '2022-07-11 04:38:53', '2022-07-11 04:38:53'),
(5, 'App\\Models\\User', 1, 'auth_token', 'c1a7ae8cf760bb9fece4aa38264ee71518d7b2181b96078b9c340a0bc13d3d3f', '[\"*\"]', NULL, '2022-07-22 08:44:33', '2022-07-22 08:44:33'),
(6, 'App\\Models\\User', 1, 'auth_token', 'bac12268b3cc563b2d53971eae65f1005aa6f6fa6137b0cd57747bd949cbed73', '[\"*\"]', '2022-07-26 19:39:02', '2022-07-22 08:44:36', '2022-07-26 19:39:02'),
(7, 'App\\Models\\AkunPegawai', 1, 'auth_token', '832f02a6c0b47b1a137dc681813deaebe5689370d5f79f565ad712b26e51b6ec', '[\"*\"]', NULL, '2022-07-22 08:45:10', '2022-07-22 08:45:10'),
(8, 'App\\Models\\AkunPegawai', 1, 'auth_token', '08a4ba8e7f9800c6151bb75dac25a784e6bc60539d853e0255ca4f6a0898f9f1', '[\"*\"]', NULL, '2022-07-22 08:45:45', '2022-07-22 08:45:45'),
(9, 'App\\Models\\AkunPegawai', 1, 'auth_token', '2cdb62eb1c796414e9970ca63859fe8a7b53904ccaea519eff2a4a06a69683e7', '[\"*\"]', NULL, '2022-07-22 09:24:58', '2022-07-22 09:24:58'),
(10, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'f70da04796bae33721d6b70de90f60823b9417d360bc4394cf7741567ea6cd7b', '[\"*\"]', NULL, '2022-07-22 21:41:00', '2022-07-22 21:41:00'),
(11, 'App\\Models\\AkunPegawai', 1, 'auth_token', '0f69cbda4562f6f54c0ecaf784a7a1a2a01703d3f1be2ddd4c3a21cea2a4fdfd', '[\"*\"]', NULL, '2022-07-22 22:04:41', '2022-07-22 22:04:41'),
(12, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'f1e09ebfb6b0c32228de57a478c0dcd47f5f6b64fdc9d35713fd419d9eeb717e', '[\"*\"]', NULL, '2022-07-22 22:39:25', '2022-07-22 22:39:25'),
(13, 'App\\Models\\AkunPegawai', 1, 'auth_token', '09bf834d243cac28aa76f23d25685293f66f8b4ca92bea8c9662b834d346bcd9', '[\"*\"]', NULL, '2022-07-22 23:06:51', '2022-07-22 23:06:51'),
(14, 'App\\Models\\AkunPegawai', 1, 'auth_token', '80e2c4af9f4b36a08e7cb1f742b94533fc55bb5afe59dd8a5a6979993120758f', '[\"*\"]', NULL, '2022-07-22 23:07:54', '2022-07-22 23:07:54'),
(15, 'App\\Models\\AkunPegawai', 1, 'auth_token', '136d99e8843b9125427d6ff11e609245bc33da788b58e86467f8267ee8fee2f8', '[\"*\"]', NULL, '2022-07-22 23:08:36', '2022-07-22 23:08:36'),
(16, 'App\\Models\\AkunPegawai', 1, 'auth_token', '49eded26cb4472e173f1454a8bd47cae9acd58016419ab12d048ca0103a7e931', '[\"*\"]', NULL, '2022-07-22 23:09:18', '2022-07-22 23:09:18'),
(17, 'App\\Models\\AkunPegawai', 1, 'auth_token', '48976e5d36021fc2f7cee0b2f168cd69f56a675933d4cee23c76701e3727686a', '[\"*\"]', NULL, '2022-07-22 23:13:29', '2022-07-22 23:13:29'),
(18, 'App\\Models\\AkunPegawai', 1, 'auth_token', '35aaa6c0bf9a9ebe11cf007d9f23481c55356c9b6a4e111cdbd7b577d4d8ff42', '[\"*\"]', NULL, '2022-07-22 23:14:12', '2022-07-22 23:14:12'),
(19, 'App\\Models\\AkunPegawai', 1, 'auth_token', '28f63a525dfd88c83dad8a8fdeab05303ec15965dcefcf480956d553e1b1290e', '[\"*\"]', NULL, '2022-07-22 23:17:57', '2022-07-22 23:17:57'),
(20, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'd2f9d0c411f8e09ac6e7931b8725df5e9222d4ae3bcf7c078dbfe18bc0f3f0fa', '[\"*\"]', NULL, '2022-07-22 23:19:26', '2022-07-22 23:19:26'),
(21, 'App\\Models\\AkunPegawai', 1, 'auth_token', '2050cbac36a92c2b3b0612910c081bf1a7031f2094c50e2d9c308b27e58eae70', '[\"*\"]', NULL, '2022-07-22 23:20:20', '2022-07-22 23:20:20'),
(22, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'c9fcfb21f46117198f9da3b2ee9f0f3e089581f6e7243a62459682c84a6701d6', '[\"*\"]', NULL, '2022-07-23 04:20:24', '2022-07-23 04:20:24'),
(23, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'd28eabdd41d6ad0c7b4abf1e98493dd7a282148016263426ca35426c886233f0', '[\"*\"]', NULL, '2022-07-23 04:20:25', '2022-07-23 04:20:25'),
(24, 'App\\Models\\AkunPegawai', 1, 'auth_token', '06fc901ed71e11a99ed0425f47ac24c82cd831db49057f3b6b3b621b618cf989', '[\"*\"]', NULL, '2022-07-23 04:51:57', '2022-07-23 04:51:57'),
(25, 'App\\Models\\AkunPegawai', 1, 'auth_token', '1dca0d11a624d67822b2008837f5b43049a423af81839ee4b4c5988ede85fec2', '[\"*\"]', NULL, '2022-07-23 06:08:18', '2022-07-23 06:08:18'),
(26, 'App\\Models\\AkunPegawai', 1, 'auth_token', '11c3ecc65e0e4712d0d9f1f43ec4c834ba2ae8ed7d2424178e1f09a466d4c8e5', '[\"*\"]', NULL, '2022-07-23 06:08:19', '2022-07-23 06:08:19'),
(27, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'e6f45a52947173425c66ca0b369700948b89afaf5e31e9637db41d2b353e776e', '[\"*\"]', NULL, '2022-07-23 06:12:45', '2022-07-23 06:12:45'),
(28, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'd4af9b91cea6a1f937db93e2508a9f83c925eb3b7ebed15ae95f7ea813c96d4a', '[\"*\"]', NULL, '2022-07-23 06:21:07', '2022-07-23 06:21:07'),
(29, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'aa9168c7386b471159e9efeae7db60be1a8a982c94e7f34dfe5eccb37198c619', '[\"*\"]', NULL, '2022-07-23 06:21:42', '2022-07-23 06:21:42'),
(30, 'App\\Models\\AkunPegawai', 1, 'auth_token', '96dcb9c16b564d165e4ce8578bf9c32890852995cdf32658e1b49fd69ae1401e', '[\"*\"]', NULL, '2022-07-23 06:22:56', '2022-07-23 06:22:56'),
(31, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'fe29682c386787120d70ec5cccc4fc6b1f2e8a3b853805f67b11c906c7198776', '[\"*\"]', NULL, '2022-07-23 06:23:32', '2022-07-23 06:23:32'),
(32, 'App\\Models\\AkunPegawai', 1, 'auth_token', '47d72e465baa870577a1724cab5a568c275ac957359ca854f14cb2f5230ea3d1', '[\"*\"]', NULL, '2022-07-23 08:36:12', '2022-07-23 08:36:12'),
(33, 'App\\Models\\AkunPegawai', 1, 'auth_token', '718b388e7bc2d5f56a9fc9ce23d90ad2e7948560d4d3d58c703f9a1971bf8022', '[\"*\"]', NULL, '2022-07-23 09:20:20', '2022-07-23 09:20:20'),
(34, 'App\\Models\\AkunPegawai', 1, 'auth_token', '73add0591919d080a4675d34aebb640cfc9f872407e4e8a728a7e3086428df0d', '[\"*\"]', NULL, '2022-07-23 09:20:21', '2022-07-23 09:20:21'),
(35, 'App\\Models\\AkunPegawai', 1, 'auth_token', '3c3388bba67fb9e68f042df70f31d5be95818df42c08be7e97c6d95f544b388e', '[\"*\"]', NULL, '2022-07-23 09:20:21', '2022-07-23 09:20:21'),
(36, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'b621464baa697aa82b741406078b97100f46dacea0214cb0f9860bfc4337b6ec', '[\"*\"]', NULL, '2022-07-23 09:20:22', '2022-07-23 09:20:22'),
(37, 'App\\Models\\AkunPegawai', 1, 'auth_token', '177c6e7d0cc39c7c85d37332a4333a50bc34b9fdaee7a9ad233fae2dd6b8e2ee', '[\"*\"]', NULL, '2022-07-23 09:20:22', '2022-07-23 09:20:22'),
(38, 'App\\Models\\AkunPegawai', 1, 'auth_token', '68fd671b6e25a54fa95c3e61270ed1db0300deb2d80f3468cda19ecadeb8721d', '[\"*\"]', NULL, '2022-07-23 09:20:23', '2022-07-23 09:20:23'),
(39, 'App\\Models\\AkunPegawai', 1, 'auth_token', '6562480aa178a66986ebd290efe34eab24a779e135da33ba3ea82b796b9141a6', '[\"*\"]', NULL, '2022-07-23 09:20:23', '2022-07-23 09:20:23'),
(40, 'App\\Models\\AkunPegawai', 1, 'auth_token', '8047b3c07cc0a302aae266de596f74a8149af37f2a6da2df0f16ac0ee395fe98', '[\"*\"]', NULL, '2022-07-23 09:20:24', '2022-07-23 09:20:24'),
(41, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'eb7b8c288b32d8643955ed6e25c96e3e4cddf7f191e4bc4108d5a8454cecc6ee', '[\"*\"]', NULL, '2022-07-23 09:20:26', '2022-07-23 09:20:26'),
(42, 'App\\Models\\AkunPegawai', 1, 'auth_token', '3c7cadf85dc732743ecaa811a0e1ae55cf1633816c4c478ace8608143581d8cc', '[\"*\"]', NULL, '2022-07-23 09:20:26', '2022-07-23 09:20:26'),
(43, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'f01b09edf220b741afa9410a37e7a15b00287456ba7aa96e01d3cf89ae366d7a', '[\"*\"]', NULL, '2022-07-23 09:20:27', '2022-07-23 09:20:27'),
(44, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'c4a1dba6ff455cfb40cd0386e4da06d77464b886ad41feada45fd726411f30e8', '[\"*\"]', NULL, '2022-07-23 09:20:27', '2022-07-23 09:20:27'),
(45, 'App\\Models\\AkunPegawai', 1, 'auth_token', '2fe250ac0d4e1ddc4fcebb28bd8408ce386dae7dc0a3c1145bcc4a2566e14b27', '[\"*\"]', NULL, '2022-07-23 09:20:28', '2022-07-23 09:20:28'),
(46, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'b0ab661d43423c01b789a5dae7a2a30a6b9f324af99b32eb7fc389cd2f0dc4ab', '[\"*\"]', NULL, '2022-07-23 09:20:28', '2022-07-23 09:20:28'),
(47, 'App\\Models\\AkunPegawai', 1, 'auth_token', '1c4e7a6c69b1c81683561fc83c87a1972a1d035d96569943e73603dd0e812097', '[\"*\"]', NULL, '2022-07-23 09:20:28', '2022-07-23 09:20:28'),
(48, 'App\\Models\\AkunPegawai', 1, 'auth_token', '0ab6571a811af45e007ad6d2a604d5f3c4dbc61b9f4f9694e4028c414b03ac35', '[\"*\"]', NULL, '2022-07-23 09:20:29', '2022-07-23 09:20:29'),
(49, 'App\\Models\\AkunPegawai', 1, 'auth_token', '3bd158fdca9d683ac48cd87b5b994f4dd771973d43893660599f411568b2d25c', '[\"*\"]', NULL, '2022-07-23 09:25:15', '2022-07-23 09:25:15'),
(50, 'App\\Models\\AkunPegawai', 1, 'auth_token', '8689be2f05068c916bcc2586c0a00ce959df1518f672591a5c9df9bd32c80c5b', '[\"*\"]', NULL, '2022-07-23 09:45:07', '2022-07-23 09:45:07'),
(51, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'b0c627502a0cafc735d9fc997728f97b38b38d4836622ad9659b1c04b5b6a287', '[\"*\"]', NULL, '2022-07-23 09:46:26', '2022-07-23 09:46:26'),
(52, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'a433f150c5f8a33b8931298e096c43e2779d7bc2d01bb3f8675b22a40f57d56d', '[\"*\"]', NULL, '2022-07-23 09:54:54', '2022-07-23 09:54:54'),
(53, 'App\\Models\\AkunPegawai', 1, 'auth_token', 'fdcf869cb831f720da0900a6a4443407cb21945191fb688e086a44082eb7945b', '[\"*\"]', NULL, '2022-07-23 10:03:35', '2022-07-23 10:03:35'),
(54, 'App\\Models\\User', 1, 'auth_token', '9745be8296ac26f593838e3a9f2818aac76c5cba63e51b55df84e27480947414', '[\"*\"]', NULL, '2022-07-26 19:39:15', '2022-07-26 19:39:15'),
(55, 'App\\Models\\AkunPegawai', 1, 'auth_token', '5ab114afaec7eaf8cbdb17aeab80122452351c7ae0ad476babc877a43a4ccdee', '[\"*\"]', '2022-07-26 19:39:58', '2022-07-26 19:39:49', '2022-07-26 19:39:58'),
(56, 'App\\Models\\AkunPegawai', 1, 'auth_token', '8c33ed6dd937f6ccff054250bc8979265fb523843076233a38f31dc0950026a1', '[\"*\"]', '2022-07-26 20:51:20', '2022-07-26 20:51:17', '2022-07-26 20:51:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perusahaan`
--

CREATE TABLE `perusahaan` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama_perusahaan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah_karyawan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_perusahaan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_perusahaan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provinsi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kota` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `npwp` bigint(20) DEFAULT NULL,
  `kode_pos` int(11) DEFAULT NULL,
  `det_alamat` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bidang` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `perusahaan`
--

INSERT INTO `perusahaan` (`id`, `nama_perusahaan`, `jumlah_karyawan`, `admin_perusahaan`, `email_perusahaan`, `provinsi`, `kota`, `npwp`, `kode_pos`, `det_alamat`, `bidang`, `created_at`, `updated_at`) VALUES
(1, 'ams', '100', 'admin', 'admin@gmail.com', 'jawa tengah', 'solo', 123698547, 56984, 'solo jawa tengah indonesia', 'bisnis', '2022-07-10 00:45:39', '2022-07-10 00:45:39');

-- --------------------------------------------------------

--
-- Struktur dari tabel `potongan`
--

CREATE TABLE `potongan` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_admin` int(10) UNSIGNED NOT NULL,
  `jenis_potongan` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nominal` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `reqabsen`
--

CREATE TABLE `reqabsen` (
  `uid` int(10) UNSIGNED NOT NULL,
  `id` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_pegawai` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alasan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bukti_pendukung` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_req` enum('Diproses','Diterima','Ditolak') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Diproses',
  `tanggal_req` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_absensi`
--

CREATE TABLE `tbl_absensi` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `foto_selfie` longblob NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `keterangan` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', 'e3274be5c857fb42ab72d786e281b4b8');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `akunpegawai`
--
ALTER TABLE `akunpegawai`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `izin`
--
ALTER TABLE `izin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_absensi`
--
ALTER TABLE `tbl_absensi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `akunpegawai`
--
ALTER TABLE `akunpegawai`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `izin`
--
ALTER TABLE `izin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tbl_absensi`
--
ALTER TABLE `tbl_absensi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
