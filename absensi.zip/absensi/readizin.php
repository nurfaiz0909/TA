<?php
require_once('connection.php');
$result = array();
$query = mysqli_query($CON,"SELECT id,name as nama,bukti as foto_selfie,tanggal,lokasi,keterangan FROM izin ORDER BY tanggal DESC");
while($row = mysqli_fetch_assoc($query)){
  $result[] = $row;
}
echo json_encode(array('absens'=>$result));

