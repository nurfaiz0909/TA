<?php
require_once('connection.php');
$result = array();
$email = $_POST['email'];
$password = $_POST['password'];
$query = mysqli_query($CON,"SELECT name,email,role FROM `akunpegawai` WHERE `email`='$email' AND password=MD5('$password')");
$row =  mysqli_fetch_row($query);

if (json_encode($row) == "null"){
  echo json_encode(array('status' => 'failed','name' => '', 'email' => '', 'role' => ''));
} else {
  echo json_encode(array('status' => 'success','name' => $row[0], 'email' => $row[1], 'role' => $row[2]));
}
